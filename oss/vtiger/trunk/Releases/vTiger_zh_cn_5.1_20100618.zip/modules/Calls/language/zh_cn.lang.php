<?php
/**
 * Copyright (C) 2006-2010 YUCHENG HU
 *
 * ---------------------------------------------
 * HA WEBSYSTEMS
 * http://www.hawebs.net
 * https://www.hawebs.org/forums/computer/
 *
 * CONTACT
 * huyuchengus@gmail.com / yuchenghu@hawebs.net
 * 
 * ---------------------------------------------
 * [A] GNU GENERAL PUBLIC LICENSE GNU/LGPL
 * [B] Apache License, Version 2.0
 *
 * ---------------------------------------------
 * NOTE
 * 1. 所有的语言配置文件请采用 UTF-8 编码 
 *
 * ---------------------------------------------
 */
$mod_strings=array(
'LBL_MODULE_NAME'=>'电话',
'LBL_MODULE_TITLE'=>'电话:首页',
'LBL_SEARCH_FORM_TITLE'=>'查找电话',
'LBL_LIST_FORM_TITLE'=>'电话列表',
'LBL_NEW_FORM_TITLE'=>'计划客户电话',
'LBL_LIST_CLOSE'=>'完成',
'LBL_LIST_SUBJECT'=>'主题',
'LBL_LIST_CONTACT'=>'联系人',
'LBL_LIST_RELATED_TO'=>'相关对象',
'LBL_LIST_DATE'=>'开始日期',
'LBL_LIST_TIME'=>'开始时间',
'LBL_LIST_DURATION'=>'时间',
'LBL_SUBJECT'=>'主题：',
'LBL_CONTACT_NAME'=>'联系人：',
'LBL_DESCRIPTION_INFORMATION'=>'描述信息：',
'LBL_DESCRIPTION'=>'描述：',
'LBL_STATUS'=>'状态：',
'LBL_DATE'=>'开始日期:',
'LBL_DURATION'=>'时间：',
'LBL_HOURS_MINUTES'=>'(小时/分钟)',
'LBL_CALL'=>'电话：',
'LBL_DATE_TIME'=>'开始日期与时间:',
'LBL_TIME'=>'开始时间:',
'LBL_HOURS_ABBREV'=>'时',
'LBL_MINSS_ABBREV'=>'分',
'LBL_COLON'=>'：',
'LBL_DEFAULT_STATUS'=>'已计划',
'LNK_NEW_LEAD'=>'新增线索',
'LNK_NEW_CONTACT'=>'新增联系人',
'LNK_NEW_ACCOUNT'=>'新增客户',
'LNK_NEW_OPPORTUNITY'=>'新增商机',
'LNK_NEW_CASE'=>'新增拜访',
'LNK_NEW_NOTE'=>'新增备忘录',
'LNK_NEW_CALL'=>'新增电话',
'LNK_NEW_EMAIL'=>'新增Email',
'LNK_NEW_MEETING'=>'新增会议',
'LNK_NEW_TASK'=>'新增任务',
'ERR_DELETE_RECORD'=>'必须指定纪录编号才能删除客户.',
'NTC_REMOVE_INVITEE'=>'您确定要删除这个电话邀请吗？',
'LBL_INVITEE'=>'*受邀者',

);
?>