<?php
/**
 * Copyright (C) 2006-2010 YUCHENG HU
 *
 * ---------------------------------------------
 * HA WEBSYSTEMS
 * http://www.hawebs.net
 * https://www.hawebs.org/forums/computer/
 *
 * CONTACT
 * huyuchengus@gmail.com / yuchenghu@hawebs.net
 * 
 * ---------------------------------------------
 * [A] GNU GENERAL PUBLIC LICENSE GNU/LGPL
 * [B] Apache License, Version 2.0
 *
 * ---------------------------------------------
 * NOTE
 * 1. 所有的语言配置文件请采用 UTF-8 编码 
 *
 * ---------------------------------------------
 */
$mod_strings=Array(
'LBL_MODULE_NAME'=>'客户',
'LBL_MODULE_TITLE'=>'客户：首页',
'LBL_SEARCH_FORM_TITLE'=>'搜寻客户',
'LBL_LIST_FORM_TITLE'=>'客户列表',
'LBL_NEW_FORM_TITLE'=>'新增客户',
'LBL_MEMBER_ORG_FORM_TITLE'=>'成员组织性质',
//LabelforTopAccountsinHomePage,addedfor4.2GA
'LBL_TOP_ACCOUNTS'=>'我的重要客户',
'LBL_TOP_AMOUNT'=>'金额',
'LBL_LIST_ACCOUNT_NAME'=>'客户名称',
'LBL_LIST_CITY'=>'乡镇市区',
'LBL_LIST_WEBSITE'=>'网站',
'LBL_LIST_STATE'=>'县市',
'LBL_LIST_PHONE'=>'电话',
'LBL_LIST_EMAIL_ADDRESS'=>'电子邮件地址',
'LBL_LIST_CONTACT_NAME'=>'联系人姓名',
'LBL_LIST_AMOUNT'=>'机会总计',

//DON'TCONVERTTHESETHEYAREMAPPINGS
'db_name'=>'LBL_LIST_ACCOUNT_NAME',
'db_website'=>'LBL_LIST_WEBSITE',
'db_billing_address_city'=>'LBL_LIST_CITY',

//ENDDON'TCONVERT

'LBL_ACCOUNT'=>'客户：',
'LBL_ACCOUNT_NAME'=>'客户名称：',
'LBL_PHONE'=>'电话：',
'LBL_WEBSITE'=>'网站：',
'LBL_FAX'=>'传真：',
'LBL_TICKER_SYMBOL'=>'传票符号：',
'LBL_OTHER_PHONE'=>'其它电话：',
'LBL_ANY_PHONE'=>'其它电话：',
'LBL_MEMBER_OF'=>'成员：',
'LBL_EMAIL'=>'电子邮件：',
'LBL_EMPLOYEES'=>'员工：',
'LBL_OTHER_EMAIL_ADDRESS'=>'其它电子邮件：',
'LBL_ANY_EMAIL'=>'其它电子邮件：',
'LBL_OWNERSHIP'=>'所有者：',
'LBL_RATING'=>'评价：',
'LBL_INDUSTRY'=>'行业别：',
'LBL_SIC_CODE'=>'统一编号：',
'LBL_TYPE'=>'类型：',
'LBL_ANNUAL_REVENUE'=>'年营业额：',
'LBL_ADDRESS_INFORMATION'=>'地址信息',
'LBL_ACCOUNT_INFORMATION'=>'账号信息',
'LBL_CUSTOM_INFORMATION'=>'客户信息',
'LBL_BILLING_ADDRESS'=>'账单地址：',
'LBL_SHIPPING_ADDRESS'=>'送货地址：',
'LBL_ANY_ADDRESS'=>'其它地址：',
'LBL_CITY'=>'乡镇市区：',
'LBL_STATE'=>'县市：',
'LBL_POSTAL_CODE'=>'邮政编码：',
'LBL_COUNTRY'=>'国家：',
'LBL_DESCRIPTION_INFORMATION'=>'描述信息',
'LBL_DESCRIPTION'=>'描述：',
'NTC_COPY_BILLING_ADDRESS'=>'复制账单地址内容到送货地址',
'NTC_COPY_SHIPPING_ADDRESS'=>'复制送货地址内容到账单地址',
'NTC_REMOVE_MEMBER_ORG_CONFIRMATION'=>'您确定要删除这笔成员/组织的记录吗？',
'LBL_DUPLICATE'=>'复制潜在案件客户',
'MSG_DUPLICATE'=>'由潜在案件客户中复制建立新客户，您可以点选客户列表中的客户以复制建立新的客户，并且继承它的相关数据。',

'LBL_INVITEE'=>'联系人',
'ERR_DELETE_RECORD'=>'要删除账号您必须指定一笔记录编号.',

'LBL_SELECT_ACCOUNT'=>'选择客户',
'LBL_GENERAL_INFORMATION'=>'主要信息',

//forv4releaseadded
'LBL_NEW_POTENTIAL'=>'新增潜在案件',
'LBL_POTENTIAL_TITLE'=>'潜在案件',

'LBL_NEW_TASK'=>'新增任务',
'LBL_TASK_TITLE'=>'任务',
'LBL_NEW_CALL'=>'新增电话记录',
'LBL_CALL_TITLE'=>'电话记录',
'LBL_NEW_MEETING'=>'新增会议记录',
'LBL_MEETING_TITLE'=>'会议',
'LBL_NEW_EMAIL'=>'新增电子邮件',
'LBL_EMAIL_TITLE'=>'邮件',
'LBL_NEW_CONTACT'=>'新增联系人',
'LBL_CONTACT_TITLE'=>'联系人',

//Addedvtiger_fieldsafterRC1-Release
'LBL_ALL'=>'全部',
'LBL_PROSPECT'=>'期望',
'LBL_INVESTOR'=>'投资者',
'LBL_RESELLER'=>'转售人',
'LBL_PARTNER'=>'伙伴',

//Addedfor4GA
'LBL_TOOL_FORM_TITLE'=>'客户工具',
//Addedfor4GA
'AccountName'=>'客户名称',
'Phone'=>'电话',
'Website'=>'网址',
'Fax'=>'传真',
'TickerSymbol'=>'传票符号',
'OtherPhone'=>'其它电话',
'MemberOf'=>'成员',
'Email'=>'电子邮件',
'Employees'=>'员工',
'OtherEmail'=>'其它电子邮件',
'Ownership'=>'拥有者',
'Rating'=>'评价',
'industry'=>'行业别',
'SICCode'=>'统一编号',
'Type'=>'类型',
'AnnualRevenue'=>'年营业额',
'AssignedTo'=>'负责人',
'BillingAddress'=>'账单地址',
'ShippingAddress'=>'送货地址',
'BillingCity'=>'乡镇市区',
'ShippingCity'=>'乡镇市区',
'BillingState'=>'县市',
'ShippingState'=>'县市',
'BillingCode'=>'邮政编码',
'ShippingCode'=>'邮政编码',
'BillingCountry'=>'国家',
'ShippingCountry'=>'国家',
'CreatedTime'=>'建立时间',
'ModifiedTime'=>'修改时间',
'Description'=>'描述',
'ShippingPoBox'=>'付款地址采购订单信箱',
'BillingPoBox'=>'付款地址采购订单信箱',

//Addedafter4.2patch2
'EmailOptOut'=>'拒绝电子邮件打扰',
'LBL_EMAIL_OPT_OUT'=>'拒绝电子邮件打扰：',

//Addedafter5Alpha5
'NotifyOwner'=>'提醒负责人',

//Addedforexistingpicklistentries

'--None--'=>'--无--',

'Acquired'=>'取得',
'Active'=>'启用',
'MarketFailed'=>'市场失利',
'ProjectCancelled'=>'项目取消',
'Shutdown'=>'关闭',

'Apparel'=>'存在',
'Banking'=>'银行',
'Biotechnology'=>'生物科技',
'Chemicals'=>'化学',
'Communications'=>'交通',
'Construction'=>'建筑',
'Consulting'=>'顾问',
'Education'=>'教育',
'Electronics'=>'电子',
'Energy'=>'能源',
'Engineering'=>'工程',
'Entertainment'=>'娱乐',
'Environmental'=>'环境',
'Finance'=>'财务',
'Food&Beverage'=>'饮食',
'Government'=>'政府',
'Healthcare'=>'健康照护',
'Hospitality'=>'医院',
'Insurance'=>'保险',
'Machinery'=>'机械',
'Manufacturing'=>'工厂',
'Media'=>'媒体',
'NotForProfit'=>'非营利',
'Recreation'=>'娱乐中心',
'Retail'=>'零售',
'Shipping'=>'运输',
'Technology'=>'科技',
'Telecommunications'=>'通讯',
'Transportation'=>'传输',
'Utilities'=>'工具',
'Other'=>'其它',

'Analyst'=>'分析师',
'Competitor'=>'竞争者',
'Customer'=>'客户',
'Integrator'=>'整合者',
'Investor'=>'投资者',
'Partner'=>'伙伴',
'Press'=>'新闻',
'Prospect'=>'潜在客户',
'Reseller'=>'盘商',
'LBL_START_DATE'=>'开始日期',
'LBL_END_DATE'=>'结束日期',

//Added/UpdatedforvtigerCRM5.0.4

//addedtofixtheissue#4081
'LBL_ACCOUNT_EXIST'=>'帐户名称已存在!',

//mailerexport
'LBL_MAILER_EXPORT'=>'邮寄导出',
'LBL_MAILER_EXPORT_CONTACTS_TYPE'=>'选择通讯录:',
'LBL_MAILER_EXPORT_CONTACTS_DESCR'=>'联络可能被选择通过"自定义字段"和一些标准字段。.',
'LBL_MAILER_EXPORT_RESULTS_TYPE'=>'选择导出类型:',
'LBL_MAILER_EXPORT_RESULTS_DESCR'=>'聚集从账户及其联系人的数据,还给前次搜索.',
'LBL_EXPORT_RESULTS_EMAIL'=>'导出邮件联系人数据',
'LBL_EXPORT_RESULTS_EMAIL_CORP'=>'导出邮件数据,如果联系人"电邮"为空则用"公司电邮"',
'LBL_EXPORT_RESULTS_FULL'=>'导出联系人数据，电子邮件帐户名称，地址，电话等.',

'LBL_EXPORT_RESULTS_GO'=>'导出',
'LBL_MAILER_EXPORT_IGNORE'=>'--忽略--',
'LBL_MAILER_EXPORT_CHECKED'=>'检查',
'LBL_MAILER_EXPORT_NOTCHECKED'=>'不进行检查',

//Addedafter5.0.4GA

//ModuleSequenceNumbering
'AccountNo'=>'帐号',
//END

//AccountHierarchy
'LBL_SHOW_ACCOUNT_HIERARCHY'=>'查看账号级别',

);

?>
