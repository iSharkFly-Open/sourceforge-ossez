<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

$mod_strings = Array (
'Service Contracts' => '服务合同',
'ServiceContracts' => '服务合同',
'SINGLE_ServiceContracts' => '服务合同',
'LBL_SERVICE_CONTRACT_INFORMATION' => '服务合同信息',
'LBL_CUSTOM_INFORMATION' => 'Custom Information',

'Contract No' => 'Contract No',
'Assigned To' => 'Assigned To',
'Created Time' => 'Created Time',
'Modified Time' => 'Modified Time',
'Start Date' => 'Start Date',
'Due Date' => 'Due Date',
'End Date' => 'End Date',
'Related to' => 'Related to',
'Tracking Unit' => 'Tracking Unit',
'Total Units' => 'Total Units',
'Used Units' => 'Used Units',
'Subject' => 'Subject',
'Progress'=> 'Progress (in %)',
'Type' => 'Type',
'Planned Duration' => 'Planned Duration (in Days)',
'Actual Duration' => 'Actual Duration (in Days)',
'Status' => 'Status',
'Priority' => 'Priority',

'Undefined' => 'Undefined',
'In Planning' => 'In Planning',
'In Progress' => 'In Progress',
'On Hold' => 'On Hold',
'Complete' => 'Complete',
'Archived' => 'Archived',

'Support' => 'Support',
'Services' => 'Services',
'Administrative' => 'Administrative',

'Low'=>'Low',
'Normal'=>'Normal',
'High'=>'High',

'None'=>'None',
'Hours'=>'Hours',
'Days'=>'Days',
'Incidents'=>'Incidents',

);

?>
