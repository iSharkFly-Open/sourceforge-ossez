<?php
/**
 * Copyright (C) 2006-2010 YUCHENG HU
 *
 * ---------------------------------------------
 * HA WEBSYSTEMS
 * http://www.hawebs.net
 * https://www.hawebs.org/forums/computer/
 *
 * CONTACT
 * huyuchengus@gmail.com / yuchenghu@hawebs.net
 * 
 * ---------------------------------------------
 * [A] GNU GENERAL PUBLIC LICENSE GNU/LGPL
 * [B] Apache License, Version 2.0
 *
 * ---------------------------------------------
 * NOTE
 * 1. 所有的语言配置文件请采用 UTF-8 编码 
 *
 * ---------------------------------------------
 */
$mod_strings=array(
'LBL_MODULE_NAME'=>'活动',
'LBL_MODULE_TITLE'=>'活动：首页',
'LBL_SEARCH_FORM_TITLE'=>'活动查找',
'LBL_LIST_FORM_TITLE'=>'活动列表',
'LBL_NEW_FORM_TITLE'=>'新增活动',
'LBL_TASK_INFORMATION'=>'任务信息',
'LBL_EVENT_INFORMATION'=>'事件信息',
'LBL_NAME'=>'主题:',
'LBL_CONTACT_NAME'=>'联系人：',
'LBL_OPEN_ACTIVITIES'=>'在做的活动',
'LBL_ACTIVITY'=>'活动:',
'LBL_HISTORY'=>'历史纪录',
'LBL_UPCOMING'=>'最近安排',
'LBL_TODAY'=>'显示到时间',
'LBL_NEW_TASK_BUTTON_TITLE'=>'新增任务[Alt+N]',
'LBL_NEW_TASK_BUTTON_KEY'=>'N',
'LBL_NEW_TASK_BUTTON_LABEL'=>'新增任务',
'LBL_SCHEDULE_MEETING_BUTTON_TITLE'=>'安排会议[Alt+M]',
'LBL_SCHEDULE_MEETING_BUTTON_KEY'=>'M',
'LBL_SCHEDULE_MEETING_BUTTON_LABEL'=>'安排会议',
'LBL_SCHEDULE_CALL_BUTTON_TITLE'=>'安排电话[Alt+C]',
'LBL_SCHEDULE_CALL_BUTTON_KEY'=>'C',
'LBL_SCHEDULE_CALL_BUTTON_LABEL'=>'安排电话',
'LBL_NEW_NOTE_BUTTON_TITLE'=>'新增备忘录[Alt+T]',
'LBL_NEW_ATTACH_BUTTON_TITLE'=>'附加文件[Alt+F]',
'LBL_NEW_NOTE_BUTTON_KEY'=>'T',
'LBL_NEW_ATTACH_BUTTON_KEY'=>'F',
'LBL_NEW_NOTE_BUTTON_LABEL'=>'新增备忘录',
'LBL_NEW_ATTACH_BUTTON_LABEL'=>'附加文件',
'LBL_TRACK_EMAIL_BUTTON_TITLE'=>'撰写邮件[Alt+K]',
'LBL_TRACK_EMAIL_BUTTON_KEY'=>'K',
'LBL_TRACK_EMAIL_BUTTON_LABEL'=>'撰写邮件',
'LBL_LIST_CLOSE'=>'完成',
'LBL_LIST_STATUS'=>'状态',
'LBL_LIST_CONTACT'=>'联系人',
'LBL_LIST_ACCOUNT'=>'客户',
'LBL_LIST_RELATED_TO'=>'相关对象',
'LBL_LIST_DUE_DATE'=>'到期日期',
'LBL_LIST_DATE'=>'日期',
'LBL_LIST_SUBJECT'=>'主题',
'LBL_LIST_LAST_MODIFIED'=>'最新修改',
'LBL_LIST_RECURRING_TYPE'=>'重复类型',
'ERR_DELETE_RECORD'=>'必须指定纪录编号才能删除客户.',
'NTC_NONE_SCHEDULED'=>'沒有安排.',
'LBL_ATTACHMENTS'=>'附件',
'LBL_NEW_ATTACHMENT'=>'新增附件',
'LBL_ALL'=>'所有',
'LBL_CALL'=>'电话',
'LBL_MEETING'=>'会议：',
'LBL_TASK'=>'任务',
'Subject'=>'主题',
'AssignedTo'=>'负责人',
'StartDate&Time'=>'开始日期和时间',
'TimeStart'=>'开始时间',
'NewEvent'=>'新增事件',
'NewTask'=>'新增事件',
'DueDate'=>'到期日期',
'RelatedTo'=>'相关对象',
'ContactName'=>'联系人姓名:',
'Status'=>'状态',
'Priority'=>'优先级',
'SendNotification'=>'发送通知',
'CreatedTime'=>'创建时间',
'ModifiedTime'=>'修改时间',
'ActivityType'=>'活动类型',
'Description'=>'描述',
'Duration'=>'持续',
'DurationMinutes'=>'持续分钟',
'Location'=>'地点',
'SendReminder'=>'发送提醒',
'LBL_YES'=>'是',
'LBL_NO'=>'不是',
'LBL_DAYS'=>'天',
'LBL_MINUTES'=>'分钟',
'LBL_HOURS'=>'小时',
'LBL_BEFORE_EVENT'=>'前',
'Close'=>'完成',
'StartDate'=>'开始日期',
'Type'=>'活动类型',
'EndDate'=>'结束日期',
'Recurrence'=>'重复事件',
'RecurringType'=>'重复类型',
'LBL_NOTIFICATION_ERROR'=>'邮件错误：请在设置=>发送邮件服务器设置检查您的发送邮件服务器设置或是目前使用者没有设置邮箱',
'hours/minutes'=>'小时/分钟',

);
?>